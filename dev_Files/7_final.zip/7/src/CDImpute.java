import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
/*
* To use: first change numlines int to the number lines the input text file has
* Then, set the path to File txt, this is where it reads in the data from
* Finally,scroll down, and set the path of File op, this will be a newly created txt file with the output
* Start the program
* Program by fes9
* */
public class CDImpute {
    public static void main(String args[]) throws IOException {
        ArrayList<String> files = new ArrayList<>();
        int numOfFiles=200;
        for(int i=1;i<=numOfFiles;i++) {
            files.add("C:/Users/FerCX/Desktop/ASD/3760 ("+i+")..xml");
        }
        asd(files);
    }
    public static void asd(ArrayList<String> file) throws IOException{
        String curr="";
        int Qnum=120;
        File myObj = new File("C:/Users/FerCX/Desktop/JavaWeka/weka.txt");
        myObj.createNewFile();
        FileWriter myWriter = new FileWriter("C:/Users/FerCX/Desktop/JavaWeka/weka.txt");
        myWriter.write("@relation Basecalling");
        myWriter.write("\n");
        for(int i=1; i<Qnum+1;i++) {
            myWriter.write("@attribute "+i+": numeric");
            myWriter.write("\n");
        }
        myWriter.write("@attribute class {AAAAA,AAAAC,AAAAG,AAAAT,AAACA,AAACC,AAACG,AAACT,AAAGA,AAAGC,AAAGG,AAAGT,AAATA,AAATC,AAATG,AAATT,AACAA,AACAC,AACAG,AACAT,AACCA,AACCC,AACCG,AACCT,AACGA,AACGC,AACGG,AACGT,AACTA,AACTC,AACTG,AACTT,AAGAA,AAGAC,AAGAG,AAGAT,AAGCA,AAGCC,AAGCG,AAGCT,AAGGA,AAGGC,AAGGG,AAGGT,AAGTA,AAGTC,AAGTG,AAGTT,AATAA,AATAC,AATAG,AATAT,AATCA,AATCC,AATCG,AATCT,AATGA,AATGC,AATGG,AATGT,AATTA,AATTC,AATTG,AATTT,ACAAA,ACAAC,ACAAG,ACAAT,ACACA,ACACC,ACACG,ACACT,ACAGA,ACAGC,ACAGG,ACAGT,ACATA,ACATC,ACATG,ACATT,ACCAA,ACCAC,ACCAG,ACCAT,ACCCA,ACCCC,ACCCG,ACCCT,ACCGA,ACCGC,ACCGG,ACCGT,ACCTA,ACCTC,ACCTG,ACCTT,ACGAA,ACGAC,ACGAG,ACGAT,ACGCA,ACGCC,ACGCG,ACGCT,ACGGA,ACGGC,ACGGG,ACGGT,ACGTA,ACGTC,ACGTG,ACGTT,ACTAA,ACTAC,ACTAG,ACTAT,ACTCA,ACTCC,ACTCG,ACTCT,ACTGA,ACTGC,ACTGG,ACTGT,ACTTA,ACTTC,ACTTG,ACTTT,AGAAA,AGAAC,AGAAG,AGAAT,AGACA,AGACC,AGACG,AGACT,AGAGA,AGAGC,AGAGG,AGAGT,AGATA,AGATC,AGATG,AGATT,AGCAA,AGCAC,AGCAG,AGCAT,AGCCA,AGCCC,AGCCG,AGCCT,AGCGA,AGCGC,AGCGG,AGCGT,AGCTA,AGCTC,AGCTG,AGCTT,AGGAA,AGGAC,AGGAG,AGGAT,AGGCA,AGGCC,AGGCG,AGGCT,AGGGA,AGGGC,AGGGG,AGGGT,AGGTA,AGGTC,AGGTG,AGGTT,AGTAA,AGTAC,AGTAG,AGTAT,AGTCA,AGTCC,AGTCG,AGTCT,AGTGA,AGTGC,AGTGG,AGTGT,AGTTA,AGTTC,AGTTG,AGTTT,ATAAA,ATAAC,ATAAG,ATAAT,ATACA,ATACC,ATACG,ATACT,ATAGA,ATAGC,ATAGG,ATAGT,ATATA,ATATC,ATATG,ATATT,ATCAA,ATCAC,ATCAG,ATCAT,ATCCA,ATCCC,ATCCG,ATCCT,ATCGA,ATCGC,ATCGG,ATCGT,ATCTA,ATCTC,ATCTG,ATCTT,ATGAA,ATGAC,ATGAG,ATGAT,ATGCA,ATGCC,ATGCG,ATGCT,ATGGA,ATGGC,ATGGG,ATGGT,ATGTA,ATGTC,ATGTG,ATGTT,ATTAA,ATTAC,ATTAG,ATTAT,ATTCA,ATTCC,ATTCG,ATTCT,ATTGA,ATTGC,ATTGG,ATTGT,ATTTA,ATTTC,ATTTG,ATTTT,CAAAA,CAAAC,CAAAG,CAAAT,CAACA,CAACC,CAACG,CAACT,CAAGA,CAAGC,CAAGG,CAAGT,CAATA,CAATC,CAATG,CAATT,CACAA,CACAC,CACAG,CACAT,CACCA,CACCC,CACCG,CACCT,CACGA,CACGC,CACGG,CACGT,CACTA,CACTC,CACTG,CACTT,CAGAA,CAGAC,CAGAG,CAGAT,CAGCA,CAGCC,CAGCG,CAGCT,CAGGA,CAGGC,CAGGG,CAGGT,CAGTA,CAGTC,CAGTG,CAGTT,CATAA,CATAC,CATAG,CATAT,CATCA,CATCC,CATCG,CATCT,CATGA,CATGC,CATGG,CATGT,CATTA,CATTC,CATTG,CATTT,CCAAA,CCAAC,CCAAG,CCAAT,CCACA,CCACC,CCACG,CCACT,CCAGA,CCAGC,CCAGG,CCAGT,CCATA,CCATC,CCATG,CCATT,CCCAA,CCCAC,CCCAG,CCCAT,CCCCA,CCCCC,CCCCG,CCCCT,CCCGA,CCCGC,CCCGG,CCCGT,CCCTA,CCCTC,CCCTG,CCCTT,CCGAA,CCGAC,CCGAG,CCGAT,CCGCA,CCGCC,CCGCG,CCGCT,CCGGA,CCGGC,CCGGG,CCGGT,CCGTA,CCGTC,CCGTG,CCGTT,CCTAA,CCTAC,CCTAG,CCTAT,CCTCA,CCTCC,CCTCG,CCTCT,CCTGA,CCTGC,CCTGG,CCTGT,CCTTA,CCTTC,CCTTG,CCTTT,CGAAA,CGAAC,CGAAG,CGAAT,CGACA,CGACC,CGACG,CGACT,CGAGA,CGAGC,CGAGG,CGAGT,CGATA,CGATC,CGATG,CGATT,CGCAA,CGCAC,CGCAG,CGCAT,CGCCA,CGCCC,CGCCG,CGCCT,CGCGA,CGCGC,CGCGG,CGCGT,CGCTA,CGCTC,CGCTG,CGCTT,CGGAA,CGGAC,CGGAG,CGGAT,CGGCA,CGGCC,CGGCG,CGGCT,CGGGA,CGGGC,CGGGG,CGGGT,CGGTA,CGGTC,CGGTG,CGGTT,CGTAA,CGTAC,CGTAG,CGTAT,CGTCA,CGTCC,CGTCG,CGTCT,CGTGA,CGTGC,CGTGG,CGTGT,CGTTA,CGTTC,CGTTG,CGTTT,CTAAA,CTAAC,CTAAG,CTAAT,CTACA,CTACC,CTACG,CTACT,CTAGA,CTAGC,CTAGG,CTAGT,CTATA,CTATC,CTATG,CTATT,CTCAA,CTCAC,CTCAG,CTCAT,CTCCA,CTCCC,CTCCG,CTCCT,CTCGA,CTCGC,CTCGG,CTCGT,CTCTA,CTCTC,CTCTG,CTCTT,CTGAA,CTGAC,CTGAG,CTGAT,CTGCA,CTGCC,CTGCG,CTGCT,CTGGA,CTGGC,CTGGG,CTGGT,CTGTA,CTGTC,CTGTG,CTGTT,CTTAA,CTTAC,CTTAG,CTTAT,CTTCA,CTTCC,CTTCG,CTTCT,CTTGA,CTTGC,CTTGG,CTTGT,CTTTA,CTTTC,CTTTG,CTTTT,GAAAA,GAAAC,GAAAG,GAAAT,GAACA,GAACC,GAACG,GAACT,GAAGA,GAAGC,GAAGG,GAAGT,GAATA,GAATC,GAATG,GAATT,GACAA,GACAC,GACAG,GACAT,GACCA,GACCC,GACCG,GACCT,GACGA,GACGC,GACGG,GACGT,GACTA,GACTC,GACTG,GACTT,GAGAA,GAGAC,GAGAG,GAGAT,GAGCA,GAGCC,GAGCG,GAGCT,GAGGA,GAGGC,GAGGG,GAGGT,GAGTA,GAGTC,GAGTG,GAGTT,GATAA,GATAC,GATAG,GATAT,GATCA,GATCC,GATCG,GATCT,GATGA,GATGC,GATGG,GATGT,GATTA,GATTC,GATTG,GATTT,GCAAA,GCAAC,GCAAG,GCAAT,GCACA,GCACC,GCACG,GCACT,GCAGA,GCAGC,GCAGG,GCAGT,GCATA,GCATC,GCATG,GCATT,GCCAA,GCCAC,GCCAG,GCCAT,GCCCA,GCCCC,GCCCG,GCCCT,GCCGA,GCCGC,GCCGG,GCCGT,GCCTA,GCCTC,GCCTG,GCCTT,GCGAA,GCGAC,GCGAG,GCGAT,GCGCA,GCGCC,GCGCG,GCGCT,GCGGA,GCGGC,GCGGG,GCGGT,GCGTA,GCGTC,GCGTG,GCGTT,GCTAA,GCTAC,GCTAG,GCTAT,GCTCA,GCTCC,GCTCG,GCTCT,GCTGA,GCTGC,GCTGG,GCTGT,GCTTA,GCTTC,GCTTG,GCTTT,GGAAA,GGAAC,GGAAG,GGAAT,GGACA,GGACC,GGACG,GGACT,GGAGA,GGAGC,GGAGG,GGAGT,GGATA,GGATC,GGATG,GGATT,GGCAA,GGCAC,GGCAG,GGCAT,GGCCA,GGCCC,GGCCG,GGCCT,GGCGA,GGCGC,GGCGG,GGCGT,GGCTA,GGCTC,GGCTG,GGCTT,GGGAA,GGGAC,GGGAG,GGGAT,GGGCA,GGGCC,GGGCG,GGGCT,GGGGA,GGGGC,GGGGG,GGGGT,GGGTA,GGGTC,GGGTG,GGGTT,GGTAA,GGTAC,GGTAG,GGTAT,GGTCA,GGTCC,GGTCG,GGTCT,GGTGA,GGTGC,GGTGG,GGTGT,GGTTA,GGTTC,GGTTG,GGTTT,GTAAA,GTAAC,GTAAG,GTAAT,GTACA,GTACC,GTACG,GTACT,GTAGA,GTAGC,GTAGG,GTAGT,GTATA,GTATC,GTATG,GTATT,GTCAA,GTCAC,GTCAG,GTCAT,GTCCA,GTCCC,GTCCG,GTCCT,GTCGA,GTCGC,GTCGG,GTCGT,GTCTA,GTCTC,GTCTG,GTCTT,GTGAA,GTGAC,GTGAG,GTGAT,GTGCA,GTGCC,GTGCG,GTGCT,GTGGA,GTGGC,GTGGG,GTGGT,GTGTA,GTGTC,GTGTG,GTGTT,GTTAA,GTTAC,GTTAG,GTTAT,GTTCA,GTTCC,GTTCG,GTTCT,GTTGA,GTTGC,GTTGG,GTTGT,GTTTA,GTTTC,GTTTG,GTTTT,TAAAA,TAAAC,TAAAG,TAAAT,TAACA,TAACC,TAACG,TAACT,TAAGA,TAAGC,TAAGG,TAAGT,TAATA,TAATC,TAATG,TAATT,TACAA,TACAC,TACAG,TACAT,TACCA,TACCC,TACCG,TACCT,TACGA,TACGC,TACGG,TACGT,TACTA,TACTC,TACTG,TACTT,TAGAA,TAGAC,TAGAG,TAGAT,TAGCA,TAGCC,TAGCG,TAGCT,TAGGA,TAGGC,TAGGG,TAGGT,TAGTA,TAGTC,TAGTG,TAGTT,TATAA,TATAC,TATAG,TATAT,TATCA,TATCC,TATCG,TATCT,TATGA,TATGC,TATGG,TATGT,TATTA,TATTC,TATTG,TATTT,TCAAA,TCAAC,TCAAG,TCAAT,TCACA,TCACC,TCACG,TCACT,TCAGA,TCAGC,TCAGG,TCAGT,TCATA,TCATC,TCATG,TCATT,TCCAA,TCCAC,TCCAG,TCCAT,TCCCA,TCCCC,TCCCG,TCCCT,TCCGA,TCCGC,TCCGG,TCCGT,TCCTA,TCCTC,TCCTG,TCCTT,TCGAA,TCGAC,TCGAG,TCGAT,TCGCA,TCGCC,TCGCG,TCGCT,TCGGA,TCGGC,TCGGG,TCGGT,TCGTA,TCGTC,TCGTG,TCGTT,TCTAA,TCTAC,TCTAG,TCTAT,TCTCA,TCTCC,TCTCG,TCTCT,TCTGA,TCTGC,TCTGG,TCTGT,TCTTA,TCTTC,TCTTG,TCTTT,TGAAA,TGAAC,TGAAG,TGAAT,TGACA,TGACC,TGACG,TGACT,TGAGA,TGAGC,TGAGG,TGAGT,TGATA,TGATC,TGATG,TGATT,TGCAA,TGCAC,TGCAG,TGCAT,TGCCA,TGCCC,TGCCG,TGCCT,TGCGA,TGCGC,TGCGG,TGCGT,TGCTA,TGCTC,TGCTG,TGCTT,TGGAA,TGGAC,TGGAG,TGGAT,TGGCA,TGGCC,TGGCG,TGGCT,TGGGA,TGGGC,TGGGG,TGGGT,TGGTA,TGGTC,TGGTG,TGGTT,TGTAA,TGTAC,TGTAG,TGTAT,TGTCA,TGTCC,TGTCG,TGTCT,TGTGA,TGTGC,TGTGG,TGTGT,TGTTA,TGTTC,TGTTG,TGTTT,TTAAA,TTAAC,TTAAG,TTAAT,TTACA,TTACC,TTACG,TTACT,TTAGA,TTAGC,TTAGG,TTAGT,TTATA,TTATC,TTATG,TTATT,TTCAA,TTCAC,TTCAG,TTCAT,TTCCA,TTCCC,TTCCG,TTCCT,TTCGA,TTCGC,TTCGG,TTCGT,TTCTA,TTCTC,TTCTG,TTCTT,TTGAA,TTGAC,TTGAG,TTGAT,TTGCA,TTGCC,TTGCG,TTGCT,TTGGA,TTGGC,TTGGG,TTGGT,TTGTA,TTGTC,TTGTG,TTGTT,TTTAA,TTTAC,TTTAG,TTTAT,TTTCA,TTTCC,TTTCG,TTTCT,TTTGA,TTTGC,TTTGG,TTTGT,TTTTA,TTTTC,TTTTG,TTTTT}");
        myWriter.write("\n");
        myWriter.write("\n");
        myWriter.write("@data");
        myWriter.write("\n");
        myWriter.flush();
        for(int a=0;a<file.size();a++){ int count=0;
            float bar=(float)file.size();
            float bar2 = (float)a;
            System.out.println(bar2/bar*100);
        File txt= new File(file.get(a));
        int start=0;
        int end=0;
        int d=1;
        String basecalls="";
        ArrayList<Integer> steps = new ArrayList<Integer>();
        ArrayList<Integer> save = new ArrayList<Integer>();
        ArrayList<Integer> signals = new ArrayList<Integer>();
        String line="";
        Scanner dis=new Scanner(txt);

        for(int i=0;i<174;i++){line = dis.nextLine();}
        Scanner strsc=new Scanner(line);
        strsc.nextFloat();
        start=strsc.nextInt();
        while(d==1){
            line= dis.nextLine();
            Scanner strsc2=new Scanner(line);
            if(strsc2.hasNextFloat()){
                strsc2.nextFloat();end=strsc2.nextInt();strsc2.nextFloat();strsc2.nextInt();
                strsc2.next();steps.add(strsc2.nextInt());
            }
            else{d=0;}
        }
        for(int i=0;i<23;i++){basecalls=dis.nextLine();}
        for(int i=0;i<657;i++){line = dis.nextLine();}
        int f=1;
        while(f==1){
        if(dis.hasNextInt()){signals.add(dis.nextInt());}
        else{f=0;}
        }
        int c=0;
        int sinlen=signals.size();
        for(int u=0;u<5;u++){basecalls=basecalls.substring(1);} //to delete start 5 bases, comes from nowhere in data
        for(int u=0;u<1;u++){steps.remove(u);} //delete first step, comes from nowhere in data
        for(int u = 0;u<sinlen-end;u++){signals.remove(sinlen-u-1);} //delete last not used signals
        for(int u= start-1;u>0;u--){signals.remove(u-1);} //delete first not used signals

            int x=0;
            int y=0;
            int[] counts={0,0,0,0,0};
            int swap=0;
            int swap2=0;
            int pop=0;
            int asd=0;
            int check=0;
        while(true){
            if(x==basecalls.length()){break;}
            if(curr.length()<5){
            if(steps.get(x)==0){
                save.add(signals.get(c));
                save.add(signals.get(c+1));
                save.add(signals.get(c+2));
                save.add(signals.get(c+3));
                save.add(signals.get(c+4));
                c=c+5;
                x++;
            }
            else if (steps.get(x)==1){
                save.add(signals.get(c));
                save.add(signals.get(c+1));
                save.add(signals.get(c+2));
                save.add(signals.get(c+3));
                save.add(signals.get(c+4));
                curr=curr+basecalls.charAt(y);
                counts[curr.length()-1]=c-pop;
                pop=c;
                x++;
                y++;
                c=c+5;
                if(curr.length()==5){
                for (int i = 0; i < save.size(); i++) {
                    if(Qnum<=save.size()){break;}
                    myWriter.write(String.valueOf(save.get(i)));
                    myWriter.write(",");
                    count++;
                }
                    for (int w = 0; w < Qnum - count; w++) {
                        if(Qnum<=save.size()){break;}
                        myWriter.write("?");
                        myWriter.write(",");
                    }
                    count=0;
                    if(Qnum>save.size()) {
                        myWriter.write(curr);
                        myWriter.write("\n");
                    }
                    myWriter.flush();
                }

            }
            else if(steps.get(x)==2){
                save.add(signals.get(c));
                save.add(signals.get(c+1));
                save.add(signals.get(c+2));
                save.add(signals.get(c+3));
                save.add(signals.get(c+4));
                asd=save.size();
                int dsa=0;
                if(counts[4]>0){dsa=counts[4];}
                else if(counts[3]>0){dsa=counts[3];}
                else if(counts[2]>0){dsa=counts[2];}
                else if(counts[1]>0){dsa=counts[1];}
                else if(counts[0]>0){dsa=counts[0];}

                for(int h=asd;h>asd-(c-pop);h--){
                    save.add(save.get(h-1));
                }
                save.add(signals.get(c));
                save.add(signals.get(c+1));
                save.add(signals.get(c+2));
                save.add(signals.get(c+3));
                save.add(signals.get(c+4));
                if(curr.length()<4){
                    curr=curr+basecalls.charAt(y);
                    counts[curr.length()-1]=c-pop;
                    curr=curr+basecalls.charAt(y+1);
                    counts[curr.length()-1]=c-pop;
                    pop=c;
                }
                else if(curr.length()==4){
                    swap=counts[3];
                    counts[3]=counts[4];
                    swap2=counts[2];
                    counts[2]=swap;
                    swap=counts[1];
                    counts[1]=swap2;
                    swap2=counts[0];
                    counts[0]=swap;

                    counts[3]=c-pop;
                    counts[4]=c-pop;

                    curr=curr.substring(1);

                    curr=curr+basecalls.charAt(y);
                    counts[curr.length()-1]=c-pop;
                    curr=curr+basecalls.charAt(y+1);
                    counts[curr.length()-1]=c-pop;
                    pop=c;
                    for(int j=0;j<swap2;j++){
                        save.remove(0);
                    }
                }
                x++;
                y++;
                y++;
                c=c+5;
                if(curr.length()==5){
                    for (int i = 0; i < save.size(); i++) {
                        if(Qnum<=save.size()){break;}
                        myWriter.write(String.valueOf(save.get(i)));
                        myWriter.write(",");
                        count++;
                    }
                    for (int w = 0; w < Qnum - count; w++) {
                        if(Qnum<=save.size()){break;}
                        myWriter.write("?");
                        myWriter.write(",");
                    }
                    count=0;
                    if(Qnum>save.size()) {
                        myWriter.write(curr);
                        myWriter.write("\n");
                    }
                    myWriter.flush();
                }
            }
        }
            else{
                if(steps.get(x)==0){
                    save.add(signals.get(c));
                    save.add(signals.get(c+1));
                    save.add(signals.get(c+2));
                    save.add(signals.get(c+3));
                    save.add(signals.get(c+4));
                    c=c+5;
                    x++;
                }
                else if (steps.get(x)==1){
                    save.add(signals.get(c));
                    save.add(signals.get(c+1));
                    save.add(signals.get(c+2));
                    save.add(signals.get(c+3));
                    save.add(signals.get(c+4));

                    curr=curr.substring(1)+basecalls.charAt(y);

                    swap=counts[3];
                    counts[3]=counts[4];
                    swap2=counts[2];
                    counts[2]=swap;
                    swap=counts[1];
                    counts[1]=swap2;
                    swap2=counts[0];
                    counts[0]=swap;
                    for(int j=0;j<swap2;j++){
                        save.remove(0);
                    }
                    counts[curr.length()-1]=c-pop;
                    pop=c;
                    x++;
                    y++;
                    c=c+5;
                    if(curr.length()==5){
                        for (int i = 0; i < save.size(); i++) {
                            if(Qnum<=save.size()){break;}
                            myWriter.write(String.valueOf(save.get(i)));
                            myWriter.write(",");
                            count++;
                        }
                        for (int w = 0; w < Qnum - count; w++) {
                            if(Qnum<=save.size()){break;}
                            myWriter.write("?");
                            myWriter.write(",");
                        }
                        count=0;
                        if(Qnum>save.size()) {
                            myWriter.write(curr);
                            myWriter.write("\n");
                        }
                        myWriter.flush();
                    }

                }
                else if(steps.get(x)==2){
                    save.add(signals.get(c));
                    save.add(signals.get(c+1));
                    save.add(signals.get(c+2));
                    save.add(signals.get(c+3));
                    save.add(signals.get(c+4));
                    asd=save.size();
                    for(int h=asd;h>asd-(c-pop);h--){
                        save.add(save.get(h-1));
                    }
                    save.add(signals.get(c));
                    save.add(signals.get(c+1));
                    save.add(signals.get(c+2));
                    save.add(signals.get(c+3));
                    save.add(signals.get(c+4));

                        swap=counts[3];
                        counts[3]=counts[4];
                        swap2=counts[2];
                        counts[2]=swap;
                        swap=counts[1];
                        counts[1]=swap2;
                        swap2=counts[0];
                        counts[0]=swap;
                        counts[4]=c-pop;
                    for(int j=0;j<swap2;j++){
                        save.remove(0);
                    }
                    swap=counts[3];
                    counts[3]=counts[4];
                    swap2=counts[2];
                    counts[2]=swap;
                    swap=counts[1];
                    counts[1]=swap2;
                    swap2=counts[0];
                    counts[0]=swap;
                    counts[4]=c-pop;
                    for(int j=0;j<swap2;j++){
                        save.remove(0);
                    }
                        curr=curr.substring(2)+basecalls.charAt(y)+basecalls.charAt(y+1);
                        pop=c;

                    x++;
                    y++;
                    y++;
                    c=c+5;
                    if(curr.length()==5){
                        for (int i = 0; i < save.size(); i++) {
                            if(Qnum<=save.size()){break;}
                            myWriter.write(String.valueOf(save.get(i)));
                            myWriter.write(",");
                            count++;
                        }
                        for (int w = 0; w < Qnum - count; w++) {
                            if(Qnum<=save.size()){break;}
                            myWriter.write("?");
                            myWriter.write(",");
                        }
                        count=0;
                        if(Qnum>save.size()){
                        myWriter.write(curr);
                        myWriter.write("\n");
                        }

                        myWriter.flush();
                    }
                    }
                }

            }
        }
        }
}







