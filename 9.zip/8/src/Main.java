public class Main {
    static void main(String[] args) throws Exception{

    }
}
