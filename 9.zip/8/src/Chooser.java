import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.*;


public class Chooser extends JPanel
        implements ActionListener {
    JButton go;

    JFileChooser chooser;
    String choosertitle;
    String selected;
    public Chooser() {
        go = new JButton("Choose Folder");
        go.addActionListener(this);
        go.setPreferredSize(new Dimension(400, 100));
        add(go);
    }

    @Override
    public String toString() {
        return selected;
    }

    public void actionPerformed(ActionEvent e) {
        chooser = new JFileChooser();
        chooser.setCurrentDirectory(new java.io.File("."));
        chooser.setDialogTitle(choosertitle);
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        //
        // disable the "All files" option.
        //
        chooser.setAcceptAllFileFilterUsed(false);
        //
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            selected=chooser.getSelectedFile().toString();
        }
        else {
            selected="";
        }
    }

    public Dimension getPreferredSize(){
        return new Dimension(500, 500);
    }

}
