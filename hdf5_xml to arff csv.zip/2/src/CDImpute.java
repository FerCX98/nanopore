import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
/*
* To use: first change numlines int to the number lines the input text file has
* Then, set the path to File txt, this is where it reads in the data from
* Finally,scroll down, and set the path of File op, this will be a newly created txt file with the output
* Start the program
* Program by fes9
* */
public class CDImpute {
    public static void main(String args[]) throws IOException {
        int numlines=0;
        File txt= new File("C:/Users/FerCX/Desktop/JavaWeka/pass1.xml");
        int start=0;
        int end=0;
        int d=1;
        String basecalls="";
        ArrayList<Integer> steps = new ArrayList<Integer>();
        ArrayList<Integer> save = new ArrayList<Integer>();
        ArrayList<Integer> signals = new ArrayList<Integer>();
        String line="";
        Scanner dis=new Scanner(txt);

        for(int i=0;i<174;i++){line = dis.nextLine();}
        Scanner strsc=new Scanner(line);
        strsc.nextFloat();
        start=strsc.nextInt();
        while(d==1){
            line= dis.nextLine();
            Scanner strsc2=new Scanner(line);
            if(strsc2.hasNextFloat()){
                strsc2.nextFloat();end=strsc2.nextInt();strsc2.nextFloat();strsc2.nextInt();
                strsc2.next();steps.add(strsc2.nextInt());
            }
            else{d=0;}
        }
        for(int i=0;i<23;i++){basecalls=dis.nextLine();}
        for(int i=0;i<657;i++){line = dis.nextLine();}
        int f=1;
        while(f==1){
        if(dis.hasNextInt()){signals.add(dis.nextInt());}
        else{f=0;}
        }
        int c=0;
        File myObj = new File("C:/Users/FerCX/Desktop/JavaWeka/weka.txt");
        myObj.createNewFile();
        FileWriter myWriter = new FileWriter("C:/Users/FerCX/Desktop/JavaWeka/weka.txt");
            int x=0;
        for(int y=-1;y<basecalls.length();y++){
            if(steps.get(x)==0){
                save.add(signals.get(c));
                save.add(signals.get(c+1));
                save.add(signals.get(c+2));
                save.add(signals.get(c+3));
                save.add(signals.get(c+4));
                c=c+5;
                x++;
            }
            else if(steps.get(x)==1){

                for(int i=0;i<save.size();i++){
                    myWriter.write(String.valueOf(save.get(i)));
                    myWriter.write(",");
                }
                save.clear();

                myWriter.write(String.valueOf(signals.get(c)));
                myWriter.write(",");
                myWriter.write(String.valueOf(signals.get(c+1)));
                myWriter.write(",");
                myWriter.write(String.valueOf(signals.get(c+2)));
                myWriter.write(",");
                myWriter.write(String.valueOf(signals.get(c+3)));
                myWriter.write(",");
                myWriter.write(String.valueOf(signals.get(c+4)));
                myWriter.write(",");
                myWriter.write( basecalls.charAt(y));
                myWriter.write("\n");
                c=c+5;
                x++;

            }
            else if(steps.get(x)==2){

                for(int i=0;i<save.size();i++){
                    myWriter.write(String.valueOf(save.get(i)));
                    myWriter.write(",");
                }

                myWriter.write(String.valueOf(signals.get(c)));
                myWriter.write(",");
                myWriter.write(String.valueOf(signals.get(c+1)));
                myWriter.write(",");
                myWriter.write(String.valueOf(signals.get(c+2)));
                myWriter.write(",");
                myWriter.write(String.valueOf(signals.get(c+3)));
                myWriter.write(",");
                myWriter.write(String.valueOf(signals.get(c+4)));
                myWriter.write(",");
                myWriter.write( basecalls.charAt(y));
                myWriter.write("\n");

                for(int i=0;i<save.size();i++){
                    myWriter.write(String.valueOf(save.get(i)));
                    myWriter.write(",");
                }
                save.clear();

                myWriter.write(String.valueOf(signals.get(c)));
                myWriter.write(",");
                myWriter.write(String.valueOf(signals.get(c+1)));
                myWriter.write(",");
                myWriter.write(String.valueOf(signals.get(c+2)));
                myWriter.write(",");
                myWriter.write(String.valueOf(signals.get(c+3)));
                myWriter.write(",");
                myWriter.write(String.valueOf(signals.get(c+4)));
                myWriter.write(",");
                myWriter.write( basecalls.charAt(y+1));
                myWriter.write("\n");
                y++;
                c=c+5;
                x++;

            }
        }






    }}




